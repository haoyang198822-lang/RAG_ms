# 产能利用率提升，持续推进工艺迭代和产品性能升级

## 核心观点

中芯国际发布2025年一季报。25年第一季度，公司实现营业收入163亿元，同比增长29%；按照国际财务报告准则，毛利率为22.5%，环比大致持平。由于工厂生产性波动，一季度后半部平均销售单价下降，该影响会延续到二季度；二季度，公司给出的收入指引为环比下降4%到6%，毛利率指引为18%到20%。

持续产能扩充，产能和产能利用率同步提升。25Q1，公司整体出货量为229万片折合8英寸标准逻辑晶圆，出货量环比增长15%；公司25Q1产能利用率上升至89.6%，环比增长4.1pct。其中，12英寸产能利用率保持稳健，8英寸产能利用率上升至12英寸厂的平均水平。公司2-3年内，预计仍将保持每年5万片12英寸晶圆上下的产能增长，与75亿美元左右的资产开支规划相对应。

工业与汽车收入环比增长超两成。2025年第一季度，公司晶圆收入按应用分，智能手机、电脑与平板、消费电子、互联与可穿戴、工业与汽车占比分别为24%，17%，41%，8%和10%，主要受益于国际形势变化引起的客户提拉出货、国内以旧换新、消费补贴等政策推动的大中类产品需求的上升，以及工业与汽车产业的触底补货。尤其是汽车电子，得益于主要客户在汽车领域取得的进展和公司过去几年加大对汽车电子平台的投入和重点布局，在BCD、CIS、MCU、域控制器等领域与产业链紧密合作，公司车规产品的出货量稳步提升。

平台方面，持续推进工艺迭代和产品性能升级。25Q1，在广泛温和复苏的市场环境下，BCD、MCU、特殊存储器总体收入环比增长20%左右。在高压显示驱动HVCMOS领域，受限于产能，应用在40nm和28nm的AMOLED小屏显示驱动平台供不应求；此外，公司协同战略客户及战略合作伙伴首推40 纳米HV-RRAM 附加值高及高性价比的显示驱动芯片产品，实现量产及终端行业应用；在图像传感器CIS 及图像信号处理器ISP方面，公司持续加大技术平台部署和产能建设。

## 盈利预测与投资建议

我们预测公司25-27年归母净利润分别为56.1/68.0/78.7亿元（原25-26年预测为56.1/71.0亿元，主要调整了营收和毛利率），采用DCF估值法，给予129.48元目标价，维持买入评级。

## 风险提示

·生产设备难以购买；价格竞争过于激烈；政府补助、投资收益等其他收益不确定的风险。

## 公司主要财务信息

<table><tr><td></td><td>2023A</td><td>2024A</td><td>2025E</td><td>2026E</td><td>2027E</td></tr><tr><td>营业收入(百万元)</td><td>45,250</td><td>57,796</td><td>69,402</td><td>78,592</td><td>88,944</td></tr><tr><td>同比增长(%)</td><td>-9%</td><td>28%</td><td>20%</td><td>13%</td><td>13%</td></tr><tr><td>营业利润(百万元)</td><td>6.906</td><td>6,299</td><td>7,985</td><td>9,991</td><td>11,555</td></tr><tr><td>同比增长(%)</td><td>-53%</td><td>-9%</td><td>27%</td><td>25%</td><td>16%</td></tr><tr><td>归属母公司净利润(百万元)</td><td>4,823</td><td>3,699</td><td>5,614</td><td>6,800</td><td>7,866</td></tr><tr><td>同比增长(%)</td><td>-60%</td><td>-23%</td><td>52%</td><td>21%</td><td>16%</td></tr><tr><td>每股收益（元）</td><td>0.60</td><td>0.46</td><td>0.70</td><td>0.85</td><td>0.99</td></tr><tr><td>毛利率(%)</td><td>21.9%</td><td>18.6%</td><td>21.0%</td><td>22.2%</td><td>22.5%</td></tr><tr><td>净利率(%)</td><td>10.7%</td><td>6.4%</td><td>8.1%</td><td>8.7%</td><td>8.8%</td></tr><tr><td>净资产收益率(%)</td><td>3.5%</td><td>2.5%</td><td>3.8%</td><td>4.5%</td><td>4.9%</td></tr><tr><td>市盈率</td><td>149</td><td>194</td><td>128</td><td>106</td><td>91</td></tr><tr><td>市净率</td><td>5.0</td><td>4.8</td><td>4.8</td><td>4.6</td><td>4.4</td></tr></table>

资料来源：公司数据.东方证券研究所预测.每股收益使用最新股本全面摊薄计算.

## 投资评级

## 买入（维持）

股价（2025年05月09日） 85.83元

目标价格 129.48元

52周最高价/最低价 109.5/41元

总股本/流通A股（万股） 798,577/798,577

A股市值（百万元） 685,418

国家/地区 中国

行业 电子

报告发布日期 2025年05月11日

## 股价表现

<table><tr><td colspan="2">1周</td><td rowspan="2">1月</td><td rowspan="2">3月</td><td rowspan="2">12月</td></tr><tr><td></td><td></td></tr><tr><td>绝对表现%</td><td>-3.62</td><td>-4.82</td><td>-16.29</td><td>96.32</td></tr><tr><td>相对表现%</td><td>-5.62</td><td>-9.14</td><td>-15.09</td><td>91.36</td></tr><tr><td>沪深300%</td><td>2</td><td>4.32</td><td>-1.2</td><td>4.96</td></tr></table>

![](images/e77b1acf4463f59103df350469f36b9d3073b596b2430b23f9fbab6d68937edd.jpg)

## 证券分析师

<table><tr><td>蒯剑</td><td>021-63325888*8514</td></tr><tr><td></td><td>kuaijian@orientsec.com.cn</td></tr><tr><td></td><td>执业证书编号：S0860514050005</td></tr><tr><td></td><td>香港证监会牌照：BPT856</td></tr><tr><td>韩潇锐</td><td>hanxiaorui@orientsec.com.cn</td></tr><tr><td></td><td>执业证书编号：S0860523080004</td></tr><tr><td>薛宏伟</td><td>xuehongwei@orientsec.com.cn</td></tr><tr><td></td><td>执业证书编号：S0860524110001</td></tr></table>

## 联系人

朱茜 zhuqian@orientsec.com.cn

## 相关报告

下游需求向好持续产能扩充，25Q1淡季不2025-02-16淡

二季度营收及毛利率超预期，三季度指引2024-08-13乐观

23Q4营收逆转同比下滑趋势，持续推进产2024-04-21能中长期布局

## 盈利预测与投资建议

我们预测公司25-27年归母净利润分别为56.1/68.0/78.7亿元（原25-26年预测为56.1/71.0亿元），主要根据24 年年报和 25 年一季报，略调整了营收和毛利率。采用 DCF 估值法，给予129.48元目标价，维持买入评级。

图1：DCF核心参数假设
<table><tr><td rowspan=1 colspan=1>指标</td><td rowspan=1 colspan=1>关键假设</td></tr><tr><td rowspan=1 colspan=1>无风险利率</td><td rowspan=1 colspan=1>1.63%</td></tr><tr><td rowspan=1 colspan=1>公司beta</td><td rowspan=1 colspan=1>0.9134</td></tr><tr><td rowspan=1 colspan=1>债务成本</td><td rowspan=1 colspan=1>3.60%</td></tr><tr><td rowspan=1 colspan=1>市场收益率Rm</td><td rowspan=1 colspan=1>8.57%</td></tr><tr><td rowspan=1 colspan=1>WACC</td><td rowspan=1 colspan=1>7.92%</td></tr><tr><td rowspan=1 colspan=1>永续增长率</td><td rowspan=1 colspan=1>3.00%</td></tr></table>

数据来源：Wind、东方证券研究所

图2：股价敏感性分析
<table><tr><td rowspan=1 colspan=2></td><td rowspan=1 colspan=5>永续增长率</td></tr><tr><td rowspan=10 colspan=1>WACC</td><td rowspan=1 colspan=1>129.48</td><td rowspan=1 colspan=1>1.00%</td><td rowspan=1 colspan=1>2.00%</td><td rowspan=1 colspan=1>3.00%</td><td rowspan=1 colspan=1>4.00%</td><td rowspan=1 colspan=1>5.00%</td></tr><tr><td rowspan=1 colspan=1>5.92%</td><td rowspan=1 colspan=1>166.26</td><td rowspan=1 colspan=1>201.91</td><td rowspan=1 colspan=1>262.01</td><td rowspan=1 colspan=1>384.81</td><td rowspan=1 colspan=1>775.45</td></tr><tr><td rowspan=1 colspan=1>6.42%</td><td rowspan=1 colspan=1>144.06</td><td rowspan=1 colspan=1>171.03</td><td rowspan=1 colspan=1>213.80</td><td rowspan=1 colspan=1>291.96</td><td rowspan=1 colspan=1>480.42</td></tr><tr><td rowspan=1 colspan=1>6.92%</td><td rowspan=1 colspan=1>125.85</td><td rowspan=1 colspan=1>146.71</td><td rowspan=1 colspan=1>178.22</td><td rowspan=1 colspan=1>231.34</td><td rowspan=1 colspan=1>339.87</td></tr><tr><td rowspan=1 colspan=1>7.42%</td><td rowspan=1 colspan=1>110.69</td><td rowspan=1 colspan=1>127.11</td><td rowspan=1 colspan=1>150.96</td><td rowspan=1 colspan=1>188.79</td><td rowspan=1 colspan=1>257.90</td></tr><tr><td rowspan=1 colspan=1>7.92%</td><td rowspan=1 colspan=1>97.90</td><td rowspan=1 colspan=1>111.02</td><td rowspan=1 colspan=1>129.48</td><td rowspan=1 colspan=1>157.36</td><td rowspan=1 colspan=1>204.36</td></tr><tr><td rowspan=1 colspan=1>8.42%</td><td rowspan=1 colspan=1>87.00</td><td rowspan=1 colspan=1>97.62</td><td rowspan=1 colspan=1>112.16</td><td rowspan=1 colspan=1>133.28</td><td rowspan=1 colspan=1>166.76</td></tr><tr><td rowspan=1 colspan=1>8.92%</td><td rowspan=1 colspan=1>77.61</td><td rowspan=1 colspan=1>86.30</td><td rowspan=1 colspan=1>97.93</td><td rowspan=1 colspan=1>114.28</td><td rowspan=1 colspan=1>138.98</td></tr><tr><td rowspan=1 colspan=1>9.42%</td><td rowspan=1 colspan=1>69.47</td><td rowspan=1 colspan=1>76.65</td><td rowspan=1 colspan=1>86.06</td><td rowspan=1 colspan=1>98.94</td><td rowspan=1 colspan=1>117.67</td></tr><tr><td rowspan=1 colspan=1>9.92%</td><td rowspan=1 colspan=1>62.35</td><td rowspan=1 colspan=1>68.33</td><td rowspan=1 colspan=1>76.03</td><td rowspan=1 colspan=1>86.34</td><td rowspan=1 colspan=1>100.84</td></tr></table>

数据来源：东方证券研究所

## 风险提示

生产设备难以购买；价格竞争过于激烈；政府补助、投资收益等其他收益不确定的风险。

## 附录

图3：20Q1-24Q4公司月产能（万片/月）  
![](images/42243e76b5f7e5700743d4768d23a904606a6a59b069902a5593a8fbc8116e1a.jpg)  
数据来源：公司公告、东方证券研究所

图4：20Q1-24Q4公司逐季产能利用率  
![](images/ba05271853a570c90d0f58c6087f7cf85ff1d9cc62fc0bdb6248e5466f8a1921.jpg)  
数据来源：公司公告、东方证券研究所

附表：财务报表预测与比率分析
<table><tr><td colspan="6">资产负债表</td></tr><tr><td>单位：百万元</td><td>2023A</td><td>2024A</td><td>2025E</td><td>2026E</td><td>2027E</td></tr><tr><td>货币资金</td><td>51,235</td><td>48,029</td><td>55,521</td><td>58,944</td><td>62,261</td></tr><tr><td>应收票据、账款及款项融资</td><td>3,944</td><td>3,288</td><td>3,948</td><td>4,471</td><td>5,060</td></tr><tr><td>预付账款</td><td>752</td><td>405</td><td>487</td><td>857</td><td>969</td></tr><tr><td>存货</td><td>19,378</td><td>21,267</td><td>24,669</td><td>24,446</td><td>24,133</td></tr><tr><td>其他</td><td>21,265</td><td>33,289</td><td>31,765</td><td>31,803</td><td>31,646</td></tr><tr><td>流动资产合计</td><td>96,574</td><td>106,279</td><td>116,390</td><td>120,521</td><td>124,069</td></tr><tr><td>长期股权投资</td><td>14,484</td><td>9,004</td><td>12,289</td><td>11,926</td><td>11,073</td></tr><tr><td>固定资产</td><td>92,432</td><td>113,545</td><td>104,379</td><td>97,597</td><td>95,313</td></tr><tr><td>在建工程</td><td>77,003</td><td>88,275</td><td>123,542</td><td>143,310</td><td>146,694</td></tr><tr><td>无形资产</td><td>3,344</td><td>3,225</td><td>2,867</td><td>2,509</td><td>2,150</td></tr><tr><td>其他</td><td>54,626</td><td>33,086</td><td>29,804</td><td>29,804</td><td>29,804</td></tr><tr><td>非流动资产合计</td><td>241,889</td><td>247,137</td><td>272,881</td><td>285,145</td><td>285,034</td></tr><tr><td>资产总计</td><td>338,463</td><td>353,415</td><td>389,272</td><td>405,666</td><td>409,103</td></tr><tr><td>短期借款</td><td>3,398</td><td>1,070</td><td>37,686</td><td>43,052</td><td>34,630</td></tr><tr><td>应付票据及应付账款</td><td>4,940</td><td>5,658</td><td>6,592</td><td>7,349</td><td>8,291</td></tr><tr><td>其他</td><td>44,277</td><td>54,816</td><td>56,840</td><td>58,612</td><td>59,697</td></tr><tr><td>流动负债合计</td><td>52,614</td><td>61,544</td><td>101,119</td><td>109,013</td><td>102,617</td></tr><tr><td>长期借款</td><td>59,032</td><td>57,785</td><td>57,785</td><td>57,785</td><td>57,785</td></tr><tr><td>应付债券</td><td>4,243</td><td>0</td><td>0</td><td>0</td><td>0</td></tr><tr><td>其他</td><td>4,104</td><td>4,978</td><td>56</td><td>56</td><td>56</td></tr><tr><td>非流动负债合计</td><td>67,379</td><td>62,763</td><td>57,841</td><td>57,841</td><td>57,841</td></tr><tr><td>负债合计</td><td>119,993</td><td>124,308</td><td>158,960</td><td>166,854</td><td>160,459</td></tr><tr><td>少数股东权益</td><td>75,994</td><td>80,917</td><td>82,116</td><td>83,816</td><td>85,783</td></tr><tr><td>实收资本（或股本）</td><td>226</td><td>226</td><td>226</td><td>226</td><td>226</td></tr><tr><td>资本公积</td><td>102,332</td><td>102,906</td><td>102,906</td><td>102,906</td><td>102,906</td></tr><tr><td>留存收益</td><td>35,750</td><td>39,449</td><td>45,063</td><td>51,863</td><td>59,729</td></tr><tr><td>其他</td><td>4,168</td><td>5,609</td><td>0</td><td>0</td><td>0</td></tr><tr><td>股东权益合计</td><td>218,470</td><td>229,108</td><td>230,312</td><td>238,812</td><td>248,644</td></tr><tr><td>负债和股东权益总计</td><td>338,463</td><td>353,415</td><td>389,272</td><td>405,666</td><td>409,103</td></tr></table>

<table><tr><td colspan="6">现金流量表</td></tr><tr><td>单位：百万元</td><td>2023A</td><td>2024A</td><td>2025E</td><td>2026E</td><td>2027E</td></tr><tr><td>净利润</td><td>6,396</td><td>5,373</td><td>6,814</td><td>8,500</td><td>9,833</td></tr><tr><td>折旧摊销</td><td>19,888</td><td>24,021</td><td>27,660</td><td>32,431</td><td>39,316</td></tr><tr><td>财务费用</td><td>(3,774)</td><td>(1,833)</td><td>(690)</td><td>(648)</td><td>(841)</td></tr><tr><td>投资损失</td><td>(250)</td><td>(1,100)</td><td>(727)</td><td>(692)</td><td>(840)</td></tr><tr><td>营运资金变动</td><td>(1,187)</td><td>(7,859)</td><td>(1,322)</td><td>1,692</td><td>1,483</td></tr><tr><td>其它</td><td>1,974</td><td>4,056</td><td>(7,182)</td><td>(42)</td><td>5</td></tr><tr><td>经营活动现金流</td><td>23,048</td><td>22,659</td><td>24,551</td><td>41,239</td><td>48,955</td></tr><tr><td>资本支出</td><td>(57,826)</td><td>(56,003)</td><td>(52,915)</td><td>(45,058)</td><td>(40,058)</td></tr><tr><td>长期投资</td><td>(1,104)</td><td>5,480</td><td>(3,285)</td><td>363</td><td>853</td></tr><tr><td>其他</td><td>17,230</td><td>19,854</td><td>1,835</td><td>863</td><td>1,148</td></tr><tr><td>投资活动现金流</td><td>(41,701)</td><td>(30,669)</td><td>(54,365)</td><td>(43,831)</td><td>(38,057)</td></tr><tr><td>债权融资</td><td>13,086</td><td>13,428</td><td>0</td><td>0</td><td>0</td></tr><tr><td>股权融资</td><td>2,789</td><td>575</td><td>0</td><td>0</td><td>0</td></tr><tr><td>其他</td><td>(147)</td><td>(4,004)</td><td>37,306</td><td>6,014</td><td>(7,581)</td></tr><tr><td>筹资活动现金流</td><td>15,728</td><td>9,999</td><td>37,306</td><td>6,014</td><td>(7,581)</td></tr><tr><td>汇率变动影响</td><td>(1,338)</td><td>(257)</td><td>-0</td><td>-0</td><td>-0</td></tr><tr><td>现金净增加额</td><td>(4,263)</td><td>1,732</td><td>7,492</td><td>3,422</td><td>3,317</td></tr></table>

资料来源：东方证券研究所

<table><tr><td colspan="6">利润表</td></tr><tr><td>单位：百万元</td><td>2023A</td><td>2024A</td><td>2025E</td><td>2026E</td><td>2027E</td></tr><tr><td>营业收入</td><td>45,250</td><td>57,796</td><td>69,402</td><td>78,592</td><td>88,944</td></tr><tr><td>营业成本</td><td>35,346</td><td>47,051</td><td>54,820</td><td>61,116</td><td>68,950</td></tr><tr><td>销售费用</td><td>254</td><td>282</td><td>331</td><td>375</td><td>424</td></tr><tr><td>管理费用</td><td>3,153</td><td>3,835</td><td>4,259</td><td>4,665</td><td>5,191</td></tr><tr><td>研发费用</td><td>4,992</td><td>5,447</td><td>5,639</td><td>6,189</td><td>6,871</td></tr><tr><td>财务费用</td><td>(3,774)</td><td>(1,833)</td><td>(690)</td><td>(648)</td><td>(841)</td></tr><tr><td>资产、信用减值损失</td><td>1,334</td><td>525</td><td>217</td><td>128</td><td>114</td></tr><tr><td>公允价值变动收益</td><td>357</td><td>4</td><td>151</td><td>171</td><td>109</td></tr><tr><td>投资净收益</td><td>250</td><td>1,100</td><td>727</td><td>692</td><td>840</td></tr><tr><td>其他</td><td>2,354</td><td>2,707</td><td>2,281</td><td>2,362</td><td>2,372</td></tr><tr><td>营业利润</td><td>6,906</td><td>6,299</td><td>7,985</td><td>9,991</td><td>11,555</td></tr><tr><td>营业外收入</td><td>12</td><td>17</td><td>9</td><td>12</td><td>13</td></tr><tr><td>营业外支出</td><td>77</td><td>23</td><td>16</td><td>39</td><td>26</td></tr><tr><td>利润总额</td><td>6,840</td><td>6,292</td><td>7,979</td><td>9,965</td><td>11,541</td></tr><tr><td>所得税</td><td>444</td><td>919</td><td>1,165</td><td>1,465</td><td>1,709</td></tr><tr><td>净利润</td><td>6,396</td><td>5,373</td><td>6,814</td><td>8,500</td><td>9,833</td></tr><tr><td>少数股东损益</td><td>1,573</td><td>1,674</td><td>1,199</td><td>1,700</td><td>1,967</td></tr><tr><td>归属于母公司净利润</td><td>4,823</td><td>3,699</td><td>5,614</td><td>6,800</td><td>7,866</td></tr><tr><td>每股收益（元）</td><td>0.60</td><td>0.46</td><td>0.70</td><td>0.85</td><td>0.99</td></tr></table>

<table><tr><td>主要财务比率</td><td></td><td></td><td>2025E</td><td>2026E</td><td>2027E</td></tr><tr><td></td><td>2023A</td><td>2024A</td><td></td><td></td><td></td></tr><tr><td>成长能力 营业收入</td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>营业利润</td><td>-9%</td><td>28%</td><td>20%</td><td>13%</td><td>13%</td></tr><tr><td>归属于母公司净利润</td><td>-53%</td><td>-9%</td><td>27%</td><td>25%</td><td>16%</td></tr><tr><td>获利能力</td><td>-60%</td><td>-23%</td><td>52%</td><td>21%</td><td>16%</td></tr><tr><td>毛利率</td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>净利率</td><td>21.9%</td><td>18.6%</td><td>21.0%</td><td>22.2%</td><td>22.5%</td></tr><tr><td></td><td>10.7%</td><td>6.4%</td><td>8.1%</td><td>8.7%</td><td>8.8%</td></tr><tr><td>ROE</td><td>3.5%</td><td>2.5%</td><td>3.8%</td><td>4.5%</td><td>4.9%</td></tr><tr><td>ROIC</td><td>1.1%</td><td>1.3%</td><td>1.9%</td><td>2.2%</td><td>2.5%</td></tr><tr><td>偿债能力</td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>资产负债率</td><td>35.5%</td><td>35.2%</td><td>40.8%</td><td>41.1%</td><td>39.2%</td></tr><tr><td>净负债率</td><td>9.6%</td><td>15.4%</td><td>28.0%</td><td>27.8%</td><td>22.0%</td></tr><tr><td>流动比率</td><td>1.84</td><td>1.73</td><td>1.15</td><td>1.11</td><td>1.21</td></tr><tr><td>速动比率</td><td>1.43</td><td>1.34</td><td>0.87</td><td>0.85</td><td>0.94</td></tr><tr><td>营运能力</td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>应收账款周转率</td><td>10.9</td><td>18.0</td><td>21.6</td><td>21.0</td><td>21.0</td></tr><tr><td>存货周转率</td><td>2.0</td><td>2.1</td><td>2.1</td><td>2.2</td><td>2.5</td></tr><tr><td>总资产周转率</td><td>0.1</td><td>0.2</td><td>0.2</td><td>0.2</td><td>0.2</td></tr><tr><td>每股指标（元）</td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>每股收益</td><td>0.60</td><td>0.46</td><td>0.70</td><td>0.85</td><td>0.99</td></tr><tr><td>每股经营现金流</td><td>102.20</td><td>100.10</td><td>108.46</td><td>182.19</td><td>216.28</td></tr><tr><td>每股净资产</td><td>17.84</td><td>18.56</td><td>18.56</td><td>19.41</td><td>20.39</td></tr><tr><td>估值比率</td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>市盈率</td><td>149.0</td><td>194.3</td><td>128.0</td><td>105.7</td><td>91.3</td></tr><tr><td>市净率</td><td>5.0</td><td>4.8</td><td>4.8</td><td>4.6</td><td>4.4</td></tr><tr><td>EV/EBITDA</td><td>33.0</td><td>26.7</td><td>21.7</td><td>18.2</td><td>15.2</td></tr><tr><td>EV/EBIT</td><td>242.5</td><td>170.0</td><td>104.1</td><td>81.3</td><td>70.9</td></tr></table>

## 分析师申明

每位负责撰写本研究报告全部或部分内容的研究分析师在此作以下声明：

分析师在本报告中对所提及的证券或发行人发表的任何建议和观点均准确地反映了其个人对该证券或发行人的看法和判断；分析师薪酬的任何组成部分无论是在过去、现在及将来，均与其在本研究报告中所表述的具体建议或观点无任何直接或间接的关系。

## 投资评级和相关定义

报告发布日后的12个月内行业或公司的涨跌幅相对同期相关证券市场代表性指数的涨跌幅为基准（A股市场基准为沪深300指数，香港市场基准为恒生指数，美国市场基准为标普500指数）；

## 公司投资评级的量化标准

买入：相对强于市场基准指数收益率15%以上;

增持：相对强于市场基准指数收益率5%～15%;

中性：相对于市场基准指数收益率在-5%～+5%之间波动;

减持：相对弱于市场基准指数收益率在-5%以下。

未评级一一由于在报告发出之时该股票不在本公司研究覆盖范围内，分析师基于当时对该股票的研究状况，未给予投资评级相关信息。

暂停评级一一根据监管制度及本公司相关规定，研究报告发布之时该投资对象可能与本公司存在潜在的利益冲突情形；亦或是研究报告发布当时该股票的价值和价格分析存在重大不确定性，缺乏足够的研究依据支持分析师给出明确投资评级；分析师在上述情况下暂停对该股票给予投资评级等信息，投资者需要注意在此报告发布之前曾给予该股票的投资评级、盈利预测及目标价格等信息不再有效。

## 行业投资评级的量化标准：

看好：相对强于市场基准指数收益率5%以上;

中性：相对于市场基准指数收益率在-5%～+5%之间波动;

看淡：相对于市场基准指数收益率在-5%以下。

未评级：由于在报告发出之时该行业不在本公司研究覆盖范围内，分析师基于当时对该行业的研究状况，未给予投资评级等相关信息。

暂停评级：由于研究报告发布当时该行业的投资价值分析存在重大不确定性，缺乏足够的研究依据支持分析师给出明确行业投资评级；分析师在上述情况下暂停对该行业给予投资评级信息，投资者需要注意在此报告发布之前曾给予该行业的投资评级信息不再有效。

## 免责声明

本证券研究报告（以下简称“本报告”）由东方证券股份有限公司（以下简称“本公司”）制作及发布。

本报告仅供本公司的客户使用。本公司不会因接收人收到本报告而视其为本公司的当然客户。本报告的全体接收人应当采取必要措施防止本报告被转发给他人。

本报告是基于本公司认为可靠的且目前已公开的信息撰写，本公司力求但不保证该信息的准确性和完整性，客户也不应该认为该信息是准确和完整的。同时，本公司不保证文中观点或陈述不会发生任何变更，在不同时期，本公司可发出与本报告所载资料、意见及推测不一致的证券研究报告。本公司会适时更新我们的研究，但可能会因某些规定而无法做到。除了一些定期出版的证券研究报告之外，绝大多数证券研究报告是在分析师认为适当的时候不定期地发布。

在任何情况下，本报告中的信息或所表述的意见并不构成对任何人的投资建议，也没有考虑到个别客户特殊的投资目标、财务状况或需求。客户应考虑本报告中的任何意见或建议是否符合其特定状况，若有必要应寻求专家意见。本报告所载的资料、工具、意见及推测只提供给客户作参考之用，并非作为或被视为出售或购买证券或其他投资标的的邀请或向人作出邀请。

本报告中提及的投资价格和价值以及这些投资带来的收入可能会波动。过去的表现并不代表未来的表现，未来的回报也无法保证，投资者可能会损失本金。外汇汇率波动有可能对某些投资的价值或价格或来自这一投资的收入产生不良影响。那些涉及期货、期权及其它衍生工具的交易，因其包括重大的市场风险，因此并不适合所有投资者。

在任何情况下，本公司不对任何人因使用本报告中的任何内容所引致的任何损失负任何责任，投资者自主作出投资决策并自行承担投资风险，任何形式的分享证券投资收益或者分担证券投资损失的书面或口头承诺均为无效。

本报告主要以电子版形式分发，间或也会辅以印刷品形式分发，所有报告版权均归本公司所有。未经本公司事先书面协议授权，任何机构或个人不得以任何形式复制、转发或公开传播本报告的全部或部分内容。不得将报告内容作为诉讼、仲裁、传媒所引用之证明或依据，不得用于营利或用于未经允许的其它用途。

经本公司事先书面协议授权刊载或转发的，被授权机构承担相关刊载或者转发责任。不得对本报告进行任何有悖原意的引用、删节和修改。

提示客户及公众投资者慎重使用未经授权刊载或者转发的本公司证券研究报告，慎重使用公众媒体刊载的证券研究报告。

## 东方证券研究所

地址： 上海市中山南路318号东方国际金融广场26楼

电话： 021-63325888

传真： 021-63326786

网址： www.dfzq.com.cn